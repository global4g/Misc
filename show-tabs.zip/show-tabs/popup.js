document.addEventListener('DOMContentLoaded', function () {
  chrome.tabs.query({}, function (tabs) {
    var tabList = document.getElementById('tabList');
    tabs.forEach(function (tab) {
      var li = document.createElement('li');
      var title = tab.title || tab.url;
      var url = tab.url;
      var a = document.createElement('a');
      a.href = url;
      a.textContent = title;
      a.title = url; // Show full URL on hover
      a.target = '_blank'; // Open links in a new tab
      li.appendChild(a);
      tabList.appendChild(li);
    });
  });

  // Add event listener to copy button
  var copyBtn = document.getElementById('copyBtn');
  copyBtn.addEventListener('click', function () {
    copyToClipboard();
  });
});

function copyToClipboard() {
  var tabUrls = Array.from(document.querySelectorAll('#tabList a')).map(a => a.href).join('\n');
  navigator.clipboard.writeText(tabUrls)
    .then(() => {
      console.log('URLs copied to clipboard');
    })
    .catch(err => {
      console.error('Failed to copy URLs: ', err);
    });
}


