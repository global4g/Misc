document.addEventListener('DOMContentLoaded', function () {
  chrome.tabs.query({}, function (tabs) {
    var tabList = document.getElementById('tabList');
    tabs.forEach(function (tab) {
      var li = document.createElement('li');
      var a = document.createElement('a');
      a.href = tab.url;
      a.textContent = tab.title || tab.url;
      a.target = '_blank'; // Open links in a new tab
      li.appendChild(a);
      tabList.appendChild(li);
    });
  });
});

